<div class="main_data">
	<?php include 'news_list.php';?>
</div>