<hr>
<div><h3><?php echo get_phrase('Messages');?></h3></div>
<hr>

<div style="width:100%; text-align:center;padding:100px;color:#aaa;">
    <img src="<?php echo base_url(); ?>assets/images/inbox.png" width="70">
    <br><br>
    <div><?php echo get_phrase('Select-to-continue');?></div>
</div>